export interface User {
  email: string;
  displayName: string;
  photoURL: string | null;
}
