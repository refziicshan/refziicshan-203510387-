export interface Message {
  id: string;
  message: string;
  email: string;
  displayName: string;
  photoURL: string;
  timestamp: Date;
}
