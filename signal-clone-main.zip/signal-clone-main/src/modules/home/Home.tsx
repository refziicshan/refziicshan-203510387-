import React from "react";
import HomeChats from "./chats/HomeChats";

const Home = () => {
  return <HomeChats />;
};

export default Home;
