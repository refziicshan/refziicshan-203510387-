import React from "react";
import ChatCreate from "../modules/chat/create/ChatCreate";

const ChatCreateScreen = () => {
  return <ChatCreate />;
};

export default ChatCreateScreen;
