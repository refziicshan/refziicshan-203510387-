import React from "react";
import Login from "../modules/user/login/Login";

const LoginScreen = () => {
  return <Login />;
};

export default LoginScreen;
