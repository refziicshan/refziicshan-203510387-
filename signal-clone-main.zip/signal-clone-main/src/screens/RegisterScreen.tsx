import React from "react";
import Register from "../modules/user/register/Register";

const RegisterScreen = () => {
  return <Register />;
};

export default RegisterScreen;
