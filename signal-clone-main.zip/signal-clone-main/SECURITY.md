# Security Policy

## Reporting a Vulnerability

DM me on the contacts provided in my profile page: https://github.com/MartsTech
